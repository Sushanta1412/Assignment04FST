package testSetup;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Testbase {
	
	public static WebDriver driver;
	
	
	public static WebDriver openBrowser() {
		try {

				WebDriverManager.chromedriver().setup();	
//				ChromeOptions options = new ChromeOptions();
//				options.addArguments("--incognito");//new code
//				options.setPageLoadStrategy(PageLoadStrategy.EAGER);
//				DesiredCapabilities capabilities = new DesiredCapabilities();//new code
//				capabilities.setCapability(ChromeOptions.CAPABILITY, options);//new code
				driver = new ChromeDriver();

			

		} catch (Exception e) {
//			Report.FailTest("Unable to Launch--- " + e.getClass() + "---" + e.getMessage());
//			throw new FrameworkException("Unable to Launch--- browser  " + e.getClass() + "---" + e.getMessage());
			
			System.out.println("Unable to Launch--- browser  " + e.getClass() + "---" + e.getMessage());
		}
		return driver;
	}

}
