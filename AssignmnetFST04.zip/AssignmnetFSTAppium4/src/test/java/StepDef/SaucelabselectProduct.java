package StepDef;


import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;


import testSetup.Testbase;

public class SaucelabselectProduct extends Testbase{

	
	@Given("^user adds one item and then remove that item to go back \"([^\"]*)\"$")
	public void user_adds_one_item_and_then_remove_that_item_to_go_back(String string) throws Throwable {
		// CODE TO FIND THE PRODUCT BY SEARCHING ON THE SENT PRODUCT
		System.out.println("Selected Product: "+string);
		String p1=string.toLowerCase();
		p1=p1.replace(" ", "-");
		String itemxpathstring="add-to-cart-"+p1;
		
		//System.out.println(itemxpathstring);
		
		////button[contains(text(),\"Add to cart\")]
		Thread.sleep(1000);
				
		driver.findElement(By.xpath("//button[@id='"+itemxpathstring+"']")).click();
		System.out.println("Add to Cart button clicked");
	    
		Thread.sleep(1000);
	    //click the Shopping Cart icon
		driver.findElement(By.xpath("//a[contains(@class,\"shopping\")]")).isDisplayed();
		System.out.println("Shopping Cart icon available");
		driver.findElement(By.xpath("//a[contains(@class,\"shopping\")]")).click();
		System.out.println("Shopping Cart icon clicked");
		
		Thread.sleep(1000);
		driver.findElement(By.xpath("//span[contains(text(),\"Your Cart\")]")).isDisplayed();
		System.out.println("Cart Page displayed");
		
		Thread.sleep(1000);
		driver.findElement(By.xpath("//button[contains(text(),\"Remove\")]")).isDisplayed();
		System.out.println("Remove Button available");
		driver.findElement(By.xpath("//button[contains(text(),\"Remove\")]")).click();
		System.out.println("Remove Button clicked");
		
		Thread.sleep(1000);
		driver.findElement(By.xpath("//button[contains(@name,\"continue-shopping\")]")).isDisplayed();
		System.out.println("continue Shopping Button available");
		driver.findElement(By.xpath("//button[contains(@name,\"continue-shopping\")]")).click();
		System.out.println("Continue Shopping Button clicked");
	}

	@Given("^user adds required item to cart \"([^\"]*)\"$")
	public void user_adds_required_item_to_cart(String string) throws Throwable {
		System.out.println("Selected Product: "+string);
		String p1=string.toLowerCase();
		p1=p1.replace(" ", "-");
		String itemxpathstring="add-to-cart-"+p1;
		
		////button[contains(text(),\"Add to cart\")]
		Thread.sleep(1000);
		driver.findElement(By.xpath("//button[@id='"+itemxpathstring+"']")).click();
		//driver.findElement(By.xpath("//button[contains(@name,\"test\")]")).click();
	}

	@Given("^user sorts item low to high \"([^\"]*)\"$")
	public void user_sorts_item_low_to_high(String string) throws Throwable {
		driver.findElement(By.xpath("//span[@class='select_container']")).click();
		Thread.sleep(1000);
		Select objselect = new Select(driver.findElement(By.xpath("//select[@class='product_sort_container']")));
		objselect.selectByVisibleText(string);
		
		
	}
	
	
}
